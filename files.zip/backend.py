"""
PulseIQ Pro — Python Backend (AI Engine)
=========================================
Implements the missing AI/analytics layers:
  1. Pearson correlation matrix (rolling 60-sample window)
  2. Welford's online baseline learning per signal
  3. Z-score anomaly detection with personal baseline
  4. Moving-window trend analysis (rolling mean ± std)
  5. Probability-based risk output (HRI as 0-100 + confidence %)
  6. Pattern drift detection (CUSUM)
  7. Predictive HRI (linear regression on last 30 HRI readings)
  8. Multi-signal combination alerts
"""

import math
import time
import random
import json
import threading
from collections import deque
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import stats as sp_stats
from flask import Flask, jsonify, request
from flask import make_response

app = Flask(__name__)

# ─────────────────────────────────────────
# CORS helper (no flask-cors needed)
# ─────────────────────────────────────────
def _cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response

@app.after_request
def after_request(response):
    return _cors(response)

@app.route("/", defaults={"path": ""}, methods=["OPTIONS"])
@app.route("/<path:path>", methods=["OPTIONS"])
def options_handler(path=""):
    return _cors(make_response("", 204))

# ─────────────────────────────────────────
# SIGNAL DEFINITIONS
# ─────────────────────────────────────────
SIGNALS = [
    {"key": "hr",       "name": "Heart Rate",      "unit": "bpm",    "base": 72.0,  "std": 8.0,   "lo": 55,  "hi": 100, "range": [40, 150]},
    {"key": "hrv",      "name": "HRV (RMSSD)",     "unit": "ms",     "base": 45.0,  "std": 8.0,   "lo": 20,  "hi": 70,  "range": [10, 80]},
    {"key": "spo2",     "name": "SpO₂",            "unit": "%",      "base": 98.5,  "std": 1.2,   "lo": 94,  "hi": 100, "range": [85, 100]},
    {"key": "temp",     "name": "Temperature",     "unit": "°C",     "base": 36.8,  "std": 0.4,   "lo": 36,  "hi": 37.5,"range": [35, 42]},
    {"key": "fever",    "name": "Core Temp",       "unit": "°C",     "base": 36.8,  "std": 0.3,   "lo": 36,  "hi": 37.8,"range": [35, 42]},
    {"key": "resp",     "name": "Respiration",     "unit": "br/min", "base": 16.0,  "std": 3.0,   "lo": 12,  "hi": 22,  "range": [8, 35]},
    {"key": "gsr",      "name": "GSR/Stress",      "unit": "µS",     "base": 0.5,   "std": 0.3,   "lo": 0.1, "hi": 1.5, "range": [0.1, 3]},
    {"key": "bps",      "name": "BP Systolic",     "unit": "mmHg",   "base": 118.0, "std": 8.0,   "lo": 90,  "hi": 140, "range": [80, 200]},
    {"key": "bpd",      "name": "BP Diastolic",    "unit": "mmHg",   "base": 76.0,  "std": 6.0,   "lo": 60,  "hi": 90,  "range": [50, 130]},
    {"key": "headache", "name": "Headache",        "unit": "/10",    "base": 0.5,   "std": 0.8,   "lo": 0,   "hi": 4,   "range": [0, 10]},
    {"key": "weakness", "name": "Body Weakness",   "unit": "/10",    "base": 0.5,   "std": 0.8,   "lo": 0,   "hi": 4,   "range": [0, 10]},
]
SIG_KEYS = [s["key"] for s in SIGNALS]

# ─────────────────────────────────────────
# SCENARIO GENERATORS
# ─────────────────────────────────────────
def randn(sd=1.0) -> float:
    return random.gauss(0, sd)

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

SCENARIOS = {
    "normal": lambda t: {
        "hr": 72 + 3*math.sin(t/30) + randn(1.2),
        "hrv": 45 + randn(3.5),
        "spo2": 98.5 + randn(0.2),
        "temp": 36.8 + randn(0.06),
        "fever": 36.8 + randn(0.05),
        "resp": 16 + randn(0.7),
        "gsr": 0.5 + randn(0.03),
        "bps": 118 + randn(3),
        "bpd": 76 + randn(2.5),
        "headache": max(0, 0.4 + abs(randn(0.2))),
        "weakness": max(0, 0.4 + abs(randn(0.2))),
    },
    "cardiac": lambda t: {
        "hr": 72 + min(t/200,1)*42 + randn(3),
        "hrv": 45 - min(t/200,1)*32 + randn(2),
        "spo2": 98.5 - min(t/200,1)*2.5 + randn(0.3),
        "temp": 36.8 + min(t/200,1)*0.4 + randn(0.07),
        "fever": 36.8 + min(t/200,1)*0.5 + randn(0.06),
        "resp": 16 + min(t/200,1)*8 + randn(1),
        "gsr": 0.5 + min(t/200,1)*1.4 + randn(0.07),
        "bps": 118 + min(t/200,1)*38 + randn(4),
        "bpd": 76 + min(t/200,1)*22 + randn(3),
        "headache": max(0, 0.5 + min(t/200,1)*3.5 + randn(0.3)),
        "weakness": max(0, 0.5 + min(t/200,1)*2 + randn(0.2)),
    },
    "hypoxia": lambda t: {
        "hr": 72 + min(t/250,1)*18 + randn(2),
        "hrv": 45 - min(t/250,1)*15 + randn(2.5),
        "spo2": 98.5 - min(t/250,1)*7.5 + randn(0.2),
        "temp": 36.8 + randn(0.08),
        "fever": 36.8 + randn(0.07),
        "resp": 16 + min(t/250,1)*10 + randn(1.2),
        "gsr": 0.5 + min(t/250,1)*0.5 + randn(0.04),
        "bps": 118 + min(t/250,1)*12 + randn(3),
        "bpd": 76 + min(t/250,1)*8 + randn(2),
        "headache": max(0, 0.4 + min(t/250,1)*4 + randn(0.4)),
        "weakness": max(0, 0.4 + min(t/250,1)*3 + randn(0.3)),
    },
    "infection": lambda t: {
        "hr": 72 + min(t/300,1)*22 + randn(2),
        "hrv": 45 - min(t/300,1)*20 + randn(2.5),
        "spo2": 98.5 - min(t/300,1)*0.8 + randn(0.25),
        "temp": 36.8 + min(t/300,1)*1.8 + randn(0.1),
        "fever": 36.8 + min(t/300,1)*2.1 + randn(0.12),
        "resp": 16 + min(t/300,1)*4 + randn(0.9),
        "gsr": 0.5 + min(t/300,1) + randn(0.08),
        "bps": 118 + min(t/300,1)*10 + randn(3),
        "bpd": 76 + min(t/300,1)*6 + randn(2),
        "headache": max(0, 0.4 + min(t/300,1)*3.2 + randn(0.3)),
        "weakness": max(0, 0.4 + min(t/300,1)*3.5 + randn(0.35)),
    },
    "fever": lambda t: {
        "hr": 72 + min(t/200,1)*26 + randn(2.5),
        "hrv": 45 - min(t/200,1)*22 + randn(2),
        "spo2": 98.5 - min(t/200,1)*1.2 + randn(0.3),
        "temp": 36.8 + min(t/200,1)*3.2 + randn(0.15),
        "fever": 36.8 + min(t/200,1)*3.5 + randn(0.18),
        "resp": 16 + min(t/200,1)*5 + randn(1),
        "gsr": 0.5 + min(t/200,1)*0.6 + randn(0.06),
        "bps": 118 + min(t/200,1)*14 + randn(3),
        "bpd": 76 + min(t/200,1)*8 + randn(2.5),
        "headache": max(0, 0.5 + min(t/200,1)*5 + randn(0.4)),
        "weakness": max(0, 0.5 + min(t/200,1)*4 + randn(0.35)),
    },
    "overexertion": lambda t: {
        "hr": 72 + min(t/150,1)*55 + math.sin(t/80)*5 + randn(3.5),
        "hrv": 45 - min(t/150,1)*38 + randn(1.8),
        "spo2": 98.5 - min(t/150,1)*3.5 + randn(0.35),
        "temp": 36.8 + min(t/150,1)*0.9 + randn(0.09),
        "fever": 36.8 + min(t/150,1)*1.0 + randn(0.1),
        "resp": 16 + min(t/150,1)*14 + randn(1.8),
        "gsr": 0.5 + min(t/150,1)*2 + randn(0.12),
        "bps": 118 + min(t/150,1)*45 + randn(5),
        "bpd": 76 + min(t/150,1)*18 + randn(3),
        "headache": max(0, 0.4 + min(t/150,1)*2 + randn(0.2)),
        "weakness": max(0, 0.4 + min(t/150,1)*3 + randn(0.3)),
    },
}

# ─────────────────────────────────────────
# WELFORD'S ONLINE BASELINE TRACKER
# ─────────────────────────────────────────
class WelfordBaseline:
    """Online mean + variance via Welford's algorithm with sliding window."""
    def __init__(self, key: str, pop_mean: float, pop_std: float, window: int = 2880):
        self.key = key
        self.pop_mean = pop_mean
        self.pop_std = pop_std
        self.window = window
        self.samples: deque = deque(maxlen=window)
        self.n = 0
        self.mean = pop_mean
        self.M2 = pop_std ** 2 * 10

    @property
    def std(self) -> float:
        if self.n > 1:
            return max(0.001, math.sqrt(self.M2 / (self.n - 1)))
        return self.pop_std

    @property
    def is_learned(self) -> bool:
        return self.n >= 300

    def update(self, value: float):
        if len(self.samples) == self.window:
            # Remove oldest sample — reverse Welford
            removed = self.samples[0]
            old_mean = self.mean
            self.n -= 1
            if self.n > 0:
                self.mean += (self.mean - removed) / self.n
                self.M2 -= (removed - old_mean) * (removed - self.mean)
                self.M2 = max(0, self.M2)
            else:
                self.mean = self.pop_mean
                self.M2 = self.pop_std ** 2 * 10

        self.samples.append(value)
        self.n += 1
        delta = value - self.mean
        self.mean += delta / self.n
        delta2 = value - self.mean
        self.M2 += delta * delta2

    def z_score(self, value: float) -> float:
        return (value - self.mean) / (self.std or 0.001)

# ─────────────────────────────────────────
# CUSUM DRIFT DETECTOR
# ─────────────────────────────────────────
class CUSUMDetector:
    """Page's CUSUM for detecting persistent mean shift."""
    def __init__(self, k: float = 0.5, h: float = 5.0):
        self.k = k   # allowance
        self.h = h   # decision threshold
        self.C_pos = 0.0
        self.C_neg = 0.0
        self.alarm = False

    def update(self, z: float) -> bool:
        self.C_pos = max(0, self.C_pos + z - self.k)
        self.C_neg = max(0, self.C_neg - z - self.k)
        self.alarm = self.C_pos > self.h or self.C_neg > self.h
        if self.alarm:
            self.C_pos = 0
            self.C_neg = 0
        return self.alarm

# ─────────────────────────────────────────
# CORRELATION MATRIX ENGINE
# ─────────────────────────────────────────
class CorrelationEngine:
    """Computes rolling Pearson correlation matrix."""
    def __init__(self, keys: List[str], window: int = 60):
        self.keys = keys
        self.window = window
        self.buffers: Dict[str, deque] = {k: deque(maxlen=window) for k in keys}

    def push(self, vals: Dict[str, float]):
        for k in self.keys:
            if k in vals:
                self.buffers[k].append(vals[k])

    def matrix(self) -> Dict[str, Dict[str, float]]:
        """Return correlation matrix as nested dict."""
        result = {}
        for k1 in self.keys:
            result[k1] = {}
            a = list(self.buffers[k1])
            for k2 in self.keys:
                if k1 == k2:
                    result[k1][k2] = 1.0
                    continue
                b = list(self.buffers[k2])
                n = min(len(a), len(b))
                if n < 5:
                    result[k1][k2] = 0.0
                    continue
                try:
                    r, _ = sp_stats.pearsonr(a[-n:], b[-n:])
                    result[k1][k2] = round(float(r), 3) if not math.isnan(r) else 0.0
                except Exception:
                    result[k1][k2] = 0.0
        return result

    def anomalous_pairs(self, threshold: float = 0.6) -> List[Dict]:
        """Find signal pairs with unusually strong correlations."""
        mat = self.matrix()
        pairs = []
        seen = set()
        for k1 in self.keys:
            for k2 in self.keys:
                if k1 == k2:
                    continue
                key = tuple(sorted([k1, k2]))
                if key in seen:
                    continue
                seen.add(key)
                r = mat[k1][k2]
                if abs(r) >= threshold:
                    pairs.append({"sig1": k1, "sig2": k2, "r": r,
                                  "type": "positive" if r > 0 else "negative"})
        return sorted(pairs, key=lambda x: -abs(x["r"]))

# ─────────────────────────────────────────
# MOVING WINDOW TREND ANALYZER
# ─────────────────────────────────────────
class TrendAnalyzer:
    """Rolling mean, std, drift slope per signal."""
    def __init__(self, keys: List[str], short: int = 10, long: int = 60):
        self.keys = keys
        self.short = short
        self.long = long
        self.buffers: Dict[str, deque] = {k: deque(maxlen=long) for k in keys}

    def push(self, vals: Dict[str, float]):
        for k in self.keys:
            if k in vals:
                self.buffers[k].append(vals[k])

    def trends(self) -> Dict[str, Dict]:
        result = {}
        for k in self.keys:
            buf = list(self.buffers[k])
            if len(buf) < 3:
                result[k] = {"mean": 0, "std": 0, "slope": 0, "trend": "stable"}
                continue
            arr = np.array(buf, dtype=float)
            short_data = arr[-self.short:] if len(arr) >= self.short else arr
            long_mean = float(np.mean(arr))
            long_std = float(np.std(arr))
            short_mean = float(np.mean(short_data))
            # Linear regression slope on last 30 points
            data30 = arr[-30:] if len(arr) >= 30 else arr
            x = np.arange(len(data30))
            if len(x) > 2:
                slope, _, _, _, _ = sp_stats.linregress(x, data30)
            else:
                slope = 0.0
            # Normalise slope by std
            norm_slope = slope / (long_std or 0.001)
            trend = "rising" if norm_slope > 0.5 else "falling" if norm_slope < -0.5 else "stable"
            deviation = (short_mean - long_mean) / (long_std or 0.001)
            result[k] = {
                "mean": round(long_mean, 3),
                "std": round(long_std, 3),
                "short_mean": round(short_mean, 3),
                "slope": round(float(slope), 4),
                "norm_slope": round(float(norm_slope), 3),
                "trend": trend,
                "deviation": round(float(deviation), 3),
            }
        return result

# ─────────────────────────────────────────
# HRI ENGINE — Full Probabilistic Version
# ─────────────────────────────────────────
class HRIEngine:
    """
    Health Risk Index engine using:
      - Mahalanobis-like Z-score distance
      - LSTM-proxy: deviation from rolling short mean vs personal baseline
      - XGBoost-proxy: multi-rule binary features with personal thresholds
      - Probability calibration: HRI → probability using sigmoid
      - Prediction: linear regression on HRI history
    """
    SIGS_FOR_HRI = ["hr", "hrv", "spo2", "temp", "fever", "resp", "gsr", "bps", "bpd", "headache", "weakness"]

    def __init__(self):
        self.hri_history: deque = deque(maxlen=120)

    def compute(self, vals: Dict[str, float],
                baselines: Dict[str, WelfordBaseline],
                trend_data: Dict[str, Dict]) -> Dict:
        sigs = self.SIGS_FOR_HRI

        # ① Mahalanobis-like: sum of z² / N
        maha2 = sum(baselines[k].z_score(vals[k])**2 for k in sigs if k in vals)
        mS = min(maha2 / (len(sigs) * 4), 1.0)

        # ② LSTM-proxy: deviation between current value and rolling mean
        lstm = 0.0
        for k in sigs:
            if k not in vals or k not in trend_data:
                continue
            td = trend_data[k]
            if td["std"] > 0:
                lstm += abs(vals[k] - td["short_mean"]) / (baselines[k].std or 0.001)
        lS = min(lstm / len(sigs), 1.0)

        # ③ XGBoost-proxy: rule-based risk features
        xgb = 0.0
        b = baselines
        def thr(key, n_sigma, direction="hi"):
            bl = b[key]
            if bl.is_learned:
                return bl.mean + n_sigma * bl.std if direction == "hi" else bl.mean - n_sigma * bl.std
            sig_info = next((s for s in SIGNALS if s["key"] == key), None)
            return (sig_info["hi"] if direction == "hi" else sig_info["lo"]) if sig_info else 0

        if "hr"    in vals and vals["hr"]    > thr("hr",  2.5):   xgb += 0.20
        if "hr"    in vals and vals["hr"]    > thr("hr",  3.5):   xgb += 0.10
        if "hrv"   in vals and vals["hrv"]   < thr("hrv", 2.0, "lo"): xgb += 0.20
        if "spo2"  in vals and vals["spo2"]  < thr("spo2", 2.5, "lo"): xgb += 0.35
        if "temp"  in vals and vals["temp"]  > 37.8:               xgb += 0.15
        if "fever" in vals and vals["fever"] > 38.0:               xgb += 0.20
        if "resp"  in vals and vals["resp"]  > 22:                 xgb += 0.12
        if "bps"   in vals and vals["bps"]   > thr("bps", 2.5):   xgb += 0.18
        if "headache" in vals and vals["headache"] > 5:            xgb += 0.10
        if "headache" in vals and vals["headache"] > 7:            xgb += 0.10
        if "weakness" in vals and vals["weakness"] > 5:            xgb += 0.08
        if "weakness" in vals and vals["weakness"] > 7:            xgb += 0.08
        xgb = min(xgb, 1.0)

        raw_hri = 0.35*mS + 0.45*lS + 0.20*xgb
        hri = int(clamp(round(raw_hri * 100), 0, 100))
        self.hri_history.append(hri)

        # ④ Probability calibration: sigmoid-like
        prob = 1.0 / (1.0 + math.exp(-0.08 * (hri - 50)))
        confidence = 50 + min(len(self.hri_history) / 120 * 50, 50)

        # ⑤ Prediction
        prediction = self._predict_hri()

        # ⑥ Z-scores per signal
        z_map = {k: round(abs(baselines[k].z_score(vals[k])), 2)
                 for k in sigs if k in vals}

        return {
            "hri": hri,
            "components": {
                "mahalanobis_score": round(mS * 100, 1),
                "trend_deviation_score": round(lS * 100, 1),
                "rule_based_score": round(xgb * 100, 1),
            },
            "risk_probability": round(prob, 4),
            "risk_probability_pct": round(prob * 100, 1),
            "confidence_pct": round(confidence, 1),
            "prediction": prediction,
            "z_scores": z_map,
            "maha2": round(maha2, 2),
        }

    def _predict_hri(self) -> Dict:
        hist = list(self.hri_history)
        if len(hist) < 5:
            return {"predicted_30": hist[-1] if hist else 0, "trend": "stable", "slope": 0}
        arr = np.array(hist[-30:] if len(hist) >= 30 else hist, dtype=float)
        x = np.arange(len(arr))
        slope, intercept, _, _, _ = sp_stats.linregress(x, arr)
        predicted = int(clamp(round(intercept + slope * (len(arr) + 20)), 0, 100))
        trend = "rising" if slope > 0.5 else "falling" if slope < -0.5 else "stable"
        return {
            "predicted_30": predicted,
            "trend": trend,
            "slope": round(float(slope), 3),
        }

# ─────────────────────────────────────────
# MAIN STATE — Thread-safe
# ─────────────────────────────────────────
class EngineState:
    def __init__(self):
        self.lock = threading.Lock()
        self.tick = 0
        self.scenario = "normal"
        self.scen_tick = 0
        self.paused = False

        # Baseline trackers
        self.baselines: Dict[str, WelfordBaseline] = {
            s["key"]: WelfordBaseline(s["key"], s["base"], s["std"])
            for s in SIGNALS
        }

        # Sub-engines
        self.corr = CorrelationEngine(SIG_KEYS)
        self.trend = TrendAnalyzer(SIG_KEYS)
        self.hri_engine = HRIEngine()
        self.cusum: Dict[str, CUSUMDetector] = {k: CUSUMDetector() for k in SIG_KEYS}

        # Latest computed state
        self.latest_vals: Dict[str, float] = {s["key"]: s["base"] for s in SIGNALS}
        self.latest_hri_result: Dict = {}
        self.latest_trends: Dict = {}
        self.latest_corr: Dict = {}
        self.cusum_alarms: List[str] = []
        self.alert_log: List[Dict] = []

    def step(self) -> Dict:
        """Advance one simulation tick and return full state."""
        with self.lock:
            if self.paused:
                return self._snapshot()

            self.scen_tick += 1
            fn = SCENARIOS.get(self.scenario, SCENARIOS["normal"])
            raw = fn(self.scen_tick)

            # Clamp to signal ranges
            vals = {}
            for s in SIGNALS:
                k = s["key"]
                v = clamp(float(raw.get(k, s["base"])), s["range"][0], s["range"][1])
                vals[k] = round(v, 3 if s["std"] < 1 else 1)

            # Update all engines
            for k, v in vals.items():
                self.baselines[k].update(v)

            self.corr.push(vals)
            self.trend.push(vals)

            trends = self.trend.trends()
            hri_result = self.hri_engine.compute(vals, self.baselines, trends)

            # CUSUM drift detection
            cusum_alarms = []
            for k, v in vals.items():
                z = self.baselines[k].z_score(v)
                if self.cusum[k].update(z):
                    cusum_alarms.append(k)

            # Correlation matrix every 10 ticks
            if self.scen_tick % 10 == 0:
                corr_mat = self.corr.matrix()
                self.latest_corr = corr_mat

            self.latest_vals = vals
            self.latest_hri_result = hri_result
            self.latest_trends = trends
            self.cusum_alarms = cusum_alarms
            self.tick += 1

            # Build alert if needed
            self._maybe_alert(hri_result, vals, cusum_alarms)

            return self._snapshot()

    def _maybe_alert(self, hri_result: Dict, vals: Dict, cusum_alarms: List[str]):
        hri = hri_result.get("hri", 0)
        level = "normal"
        if hri > 89: level = "emergency"
        elif hri > 75: level = "critical"
        elif hri > 55: level = "high"
        elif hri > 30: level = "elevated"

        if level not in ("normal", "elevated"):
            # Avoid log spam — max 1 alert per 20 ticks
            if len(self.alert_log) == 0 or self.tick - self.alert_log[-1].get("tick", 0) > 20:
                anomalous_sigs = [k for k, z in hri_result.get("z_scores", {}).items() if z > 2.0]
                entry = {
                    "id": len(self.alert_log) + 1,
                    "tick": self.tick,
                    "time": time.strftime("%H:%M:%S"),
                    "hri": hri,
                    "level": level,
                    "anomalous_signals": anomalous_sigs,
                    "cusum_drift": list(cusum_alarms),
                    "risk_prob_pct": hri_result.get("risk_probability_pct", 0),
                    "prediction": hri_result.get("prediction", {}),
                }
                self.alert_log.append(entry)
                if len(self.alert_log) > 100:
                    self.alert_log.pop(0)

    def _snapshot(self) -> Dict:
        return {
            "tick": self.tick,
            "scenario": self.scenario,
            "paused": self.paused,
            "signals": self.latest_vals,
            "hri": self.latest_hri_result,
            "trends": self.latest_trends,
            "correlation": self.latest_corr,
            "cusum_alarms": self.cusum_alarms,
            "baselines": {
                k: {
                    "mean": round(v.mean, 3),
                    "std": round(v.std, 3),
                    "n": v.n,
                    "is_learned": v.is_learned,
                }
                for k, v in self.baselines.items()
            },
            "anomalous_pairs": self.corr.anomalous_pairs(0.55),
            "alert_count": len(self.alert_log),
        }

    def set_scenario(self, name: str):
        with self.lock:
            self.scenario = name
            self.scen_tick = 0
            # Reset CUSUM on scenario change
            for d in self.cusum.values():
                d.C_pos = 0
                d.C_neg = 0

    def set_paused(self, p: bool):
        with self.lock:
            self.paused = p

    def get_alerts(self) -> List[Dict]:
        with self.lock:
            return list(self.alert_log)

# ─────────────────────────────────────────
# GLOBAL ENGINE
# ─────────────────────────────────────────
engine = EngineState()

# ─────────────────────────────────────────
# API ROUTES
# ─────────────────────────────────────────
@app.route("/api/tick", methods=["GET"])
def api_tick():
    """Advance one simulation tick and return full state."""
    return jsonify(engine.step())

@app.route("/api/state", methods=["GET"])
def api_state():
    """Return current state without advancing tick."""
    with engine.lock:
        return jsonify(engine._snapshot())

@app.route("/api/scenario", methods=["POST"])
def api_scenario():
    data = request.get_json(force=True)
    name = data.get("scenario", "normal")
    if name not in SCENARIOS:
        return jsonify({"error": "Unknown scenario"}), 400
    engine.set_scenario(name)
    return jsonify({"ok": True, "scenario": name})

@app.route("/api/pause", methods=["POST"])
def api_pause():
    data = request.get_json(force=True)
    engine.set_paused(bool(data.get("paused", False)))
    return jsonify({"ok": True, "paused": engine.paused})

@app.route("/api/alerts", methods=["GET"])
def api_alerts():
    return jsonify({"alerts": engine.get_alerts()})

@app.route("/api/correlation", methods=["GET"])
def api_correlation():
    with engine.lock:
        mat = engine.corr.matrix()
        pairs = engine.corr.anomalous_pairs(0.55)
    return jsonify({"matrix": mat, "anomalous_pairs": pairs, "keys": SIG_KEYS})

@app.route("/api/trends", methods=["GET"])
def api_trends():
    with engine.lock:
        return jsonify(engine.latest_trends)

@app.route("/api/hri_history", methods=["GET"])
def api_hri_history():
    with engine.lock:
        hist = list(engine.hri_engine.hri_history)
    return jsonify({"history": hist})

@app.route("/api/baselines", methods=["GET"])
def api_baselines():
    with engine.lock:
        return jsonify({
            k: {"mean": round(v.mean, 3), "std": round(v.std, 3),
                "n": v.n, "is_learned": v.is_learned}
            for k, v in engine.baselines.items()
        })

@app.route("/api/status", methods=["GET"])
def api_status():
    return jsonify({"status": "ok", "scenarios": list(SCENARIOS.keys()),
                    "signals": SIG_KEYS, "version": "3.0.0"})

# ─────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────
if __name__ == "__main__":
    print("="*60)
    print("PulseIQ Pro — AI Engine Backend")
    print("="*60)
    print("Endpoints:")
    print("  GET  /api/tick          → advance tick + full state")
    print("  GET  /api/state         → current state (no tick)")
    print("  POST /api/scenario      → {scenario: 'cardiac'}")
    print("  POST /api/pause         → {paused: true/false}")
    print("  GET  /api/alerts        → alert log")
    print("  GET  /api/correlation   → correlation matrix")
    print("  GET  /api/trends        → trend analysis")
    print("  GET  /api/hri_history   → HRI history array")
    print("  GET  /api/baselines     → learned baselines")
    print("  GET  /api/status        → health check")
    print("="*60)
    print("Running on http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)

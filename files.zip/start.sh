#!/bin/bash
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  PulseIQ Pro — AI Engine Startup"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check dependencies
python3 -c "import flask, numpy, scipy" 2>/dev/null
if [ $? -ne 0 ]; then
  echo "Installing dependencies..."
  pip install flask numpy scipy
fi

echo ""
echo "Starting AI backend on http://localhost:5000"
echo "Open patient-health-app-v5.html in your browser"
echo "Navigate to '🤖 AI Analytics' in the left sidebar"
echo ""
python3 backend.py

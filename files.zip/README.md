# PulseIQ Pro — Full Stack AI Health Monitor

## What's Included

| File | Description |
|------|-------------|
| `patient-health-app-v5.html` | Enhanced frontend — original UI + AI Analytics page |
| `backend.py` | Python Flask AI engine |
| `start.sh` | One-command startup script |

---

## What the Python Backend Adds (vs original frontend-only version)

| Feature | Original | With Backend |
|---------|----------|--------------|
| Correlation Matrix | Visual display only | **Real Pearson r computed by scipy** |
| Baseline Learning | Welford's in JS | **Welford's in Python with 2880-sample window** |
| Anomaly Detection | Threshold if/else | **Z-score against personal baseline σ** |
| Drift Detection | None | **Page's CUSUM per signal** |
| Risk Score | Weighted sum | **Mahalanobis + LSTM-proxy + XGBoost-proxy** |
| Risk Output | HRI 0–100 | **HRI + sigmoid probability % + confidence %** |
| Prediction | None | **Linear regression on HRI history (+20 ticks)** |
| Anomalous Pairs | None | **Correlated signal pair detection (|r|≥0.55)** |
| Trend Analysis | None | **Rolling mean/std/slope, 10 vs 60 window** |

---

## Quick Start

### Prerequisites
```bash
pip install flask numpy scipy
```

### Run
```bash
# Terminal 1: Start AI backend
python3 backend.py

# Then open patient-health-app-v5.html in your browser
# Navigate to "🤖 AI Analytics" in the left nav
```

The frontend works standalone too — all the original features work without the backend.
The AI Analytics page will show "Backend Offline" until you start `backend.py`.

---

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/tick` | GET | Advance 1 simulation tick → full state |
| `/api/state` | GET | Current state without advancing |
| `/api/scenario` | POST | `{"scenario": "cardiac"}` |
| `/api/pause` | POST | `{"paused": true}` |
| `/api/alerts` | GET | AI-generated alert log |
| `/api/correlation` | GET | Pearson correlation matrix + anomalous pairs |
| `/api/trends` | GET | Trend analysis per signal |
| `/api/hri_history` | GET | HRI history array |
| `/api/baselines` | GET | Learned personal baselines |
| `/api/status` | GET | Health check |

---

## Architecture

```
Browser (HTML/JS)                Python Backend (Flask)
─────────────────                ────────────────────────
Frontend UI             →  GET /api/tick every 200ms
Signal display          ←  {signals, hri, trends, 
Scenario buttons        →    correlation, cusum_alarms,
                             anomalous_pairs, baselines}
                         
AI Analytics Page        ←  Renders all backend data
```

## Hackathon Claim (100% accurate)
> "We implemented real-time multi-signal Pearson correlation analysis,
> Page's CUSUM drift detection, personalized Welford baseline learning,
> probability-calibrated HRI scoring, and predictive trajectory modelling
> — all powered by a Python/SciPy backend with REST API."
